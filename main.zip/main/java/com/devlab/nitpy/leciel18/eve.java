package com.devlab.nitpy.leciel18;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TableLayout;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;


public class eve extends Fragment {

    SharedPreferences sp;
    SharedPreferences.Editor e;


    public void press(View v, int id){
        Intent i=new Intent(getContext(),details.class);
        i.putExtra("id",id);
        startActivity(i);
    }






    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);




    }






    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View f=inflater.inflate(R.layout.fragment_eve, container, false);

        sp=PreferenceManager.getDefaultSharedPreferences(getContext());
        e=sp.edit();
        final View ll=f.findViewById(R.id.welcome);



        final View w=f.findViewById(R.id.w);
        final View mv=f.findViewById(R.id.mainv);
        Button but=w.findViewById(R.id.im);

        if(sp.getBoolean("wel",false)){
            w.setVisibility(View.GONE);
            mv.setVisibility(View.VISIBLE);
        }

        but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                e.putBoolean("wel",true).commit();
                w.setVisibility(View.GONE);
                mv.setVisibility(View.VISIBLE);
            }
        });




        ImageButton d= (ImageButton)f.findViewById(R.id.dance);
        ImageButton m= (ImageButton)f.findViewById(R.id.music);
        ImageButton t= (ImageButton)f.findViewById(R.id.theartrical);
        ImageButton a= (ImageButton)f.findViewById(R.id.arts);
        ImageButton l= (ImageButton)f.findViewById(R.id.lit);
        ImageButton fu= (ImageButton)f.findViewById(R.id.fun);
        ImageButton o= (ImageButton)f.findViewById(R.id.online);
        ImageButton mc=(ImageButton)f.findViewById(R.id.masco);

        d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getContext(),root.class);
                i.putExtra("cat",1);
                startActivity(i);
            }
        });

        m.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getContext(),root.class);
                i.putExtra("cat",2);
                startActivity(i);
            }
        });

        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getContext(),root.class);
                i.putExtra("cat",3);
                startActivity(i);
            }
        });

        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getContext(),root.class);
                i.putExtra("cat",4);
                startActivity(i);
            }
        });

        l.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getContext(),root.class);
                i.putExtra("cat",5);
                startActivity(i);
            }
        });

        fu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getContext(),root.class);
                i.putExtra("cat",6);
                startActivity(i);
            }
        });

        o.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getContext(),root.class);
                i.putExtra("cat",7);
                startActivity(i);
            }
        });
        mc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getContext(),root.class);
                i.putExtra("cat",8);
                startActivity(i);
            }
        });




        return f;
    }



    }

