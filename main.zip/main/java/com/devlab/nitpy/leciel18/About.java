package com.devlab.nitpy.leciel18;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;


public class About extends Fragment {



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View r=inflater.inflate(R.layout.fragment_about, container, false);
       ImageButton w=r.findViewById(R.id.imageButton);
       ImageButton f=r.findViewById(R.id.imageButton2);
       w.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
              Intent i=new Intent(Intent.ACTION_VIEW);
              i.setData(Uri.parse("http://www.lecielfest.com"));
              startActivity(i);
           }
       });
       f.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent i=new Intent(Intent.ACTION_VIEW);
               i.setData(Uri.parse("http://www.facebook.com/lecielnitpy"));
               startActivity(i);
           }
       });

       return r;
    }





    }

