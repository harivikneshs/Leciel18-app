package com.devlab.nitpy.leciel18;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class root extends AppCompatActivity {
    boolean[] flag = {false, false, false, false, false};

    SharedPreferences s;
    SharedPreferences.Editor e;
    private  Button fv,fw,fx,fy,fz;
    private View v,w,x,y,z;

    private void store(SharedPreferences.Editor e, Boolean b,String s,int i){
        String t=s+Integer.toString(i);
        e.putBoolean(t,b).commit();

    }

    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_root);

        final Intent i = getIntent();

        s= PreferenceManager.getDefaultSharedPreferences(this);
        e=s.edit();

        v=findViewById(R.id.v);
        w=findViewById(R.id.w);
        x=findViewById(R.id.x);
        y=findViewById(R.id.y);
        z=findViewById(R.id.z);

        v.setTranslationY(v.getTranslationY()+200);
        v.animate().translationYBy(-200).setDuration(500).start();

        w.setTranslationY(w.getTranslationY()+300);
        w.animate().translationYBy(-300).setDuration(500).setStartDelay(200).start();

        x.setTranslationY(x.getTranslationY()+400);
        x.animate().translationYBy(-400).setDuration(500).setStartDelay(400).start();

        y.setTranslationY(y.getTranslationY()+500);
        y.animate().translationYBy(-500).setDuration(500).setStartDelay(600).start();

        z.setTranslationY(z.getTranslationY()+600);
        z.animate().translationYBy(-600).setDuration(500).setStartDelay(800).start();

        fv = v.findViewById(R.id.favbutton);
        fw = w.findViewById(R.id.favbutton);
        fx = x.findViewById(R.id.favbutton);
        fy = y.findViewById(R.id.favbutton);
        fz = z.findViewById(R.id.favbutton);

        Typeface cf=Typeface.createFromAsset(getAssets(),"fonts/Raleway.ttf");
        ((TextView)v.findViewById(R.id.evename)).setTypeface(cf);
        ((TextView)w.findViewById(R.id.evename)).setTypeface(cf);
        ((TextView)x.findViewById(R.id.evename)).setTypeface(cf);
        ((TextView)y.findViewById(R.id.evename)).setTypeface(cf);
        ((TextView)z.findViewById(R.id.evename)).setTypeface(cf);


        switch (i.getIntExtra("cat",1)) {

            case 1:
                flag[0] = s.getBoolean("v1", false);
                flag[1] = s.getBoolean("w1", false);
                flag[2] = s.getBoolean("x1", false);
                flag[3] = s.getBoolean("y1", false);
                flag[4] = s.getBoolean("z1", false);
                break;
            case 2:
                flag[0] = s.getBoolean("v2", false);
                flag[1] = s.getBoolean("w2", false);
                flag[2] = s.getBoolean("x2", false);
                flag[3] = s.getBoolean("y2", false);
                flag[4] = s.getBoolean("z2", false);
                break;
            case 3:
                flag[0] = s.getBoolean("v3", false);
                flag[1] = s.getBoolean("w3", false);
                flag[2] = s.getBoolean("x3", false);
                flag[3] = s.getBoolean("y3", false);
                flag[4] = s.getBoolean("z3", false);
                break;
            case 4:
                flag[0] = s.getBoolean("v4", false);
                flag[1] = s.getBoolean("w4", false);
                flag[2] = s.getBoolean("x4", false);
                flag[3] = s.getBoolean("y4", false);
                flag[4] = s.getBoolean("z4", false);
                break;
            case 5:
                flag[0] = s.getBoolean("v5", false);
                flag[1] = s.getBoolean("w5", false);
                flag[2] = s.getBoolean("x5", false);
                flag[3] = s.getBoolean("y5", false);
                flag[4] = s.getBoolean("z5", false);
                break;
            case 6:
                flag[0] = s.getBoolean("v6", false);
                flag[1] = s.getBoolean("w6", false);
                flag[2] = s.getBoolean("x6", false);
                flag[3] = s.getBoolean("y6", false);
                flag[4] = s.getBoolean("z6", false);
                break;
            case 7:
                flag[0] = s.getBoolean("v7", false);
                flag[1] = s.getBoolean("w7", false);
                flag[2] = s.getBoolean("x7", false);
                flag[3] = s.getBoolean("y7", false);
                flag[4] = s.getBoolean("z7", false);
                break;
            case 8:
                flag[0]=s.getBoolean("v8",false);



        }


        if (flag[0])
            fv.setBackgroundResource(R.drawable.favfull);
        if (flag[1])
            fw.setBackgroundResource(R.drawable.favfull);
        if (flag[2])
            fx.setBackgroundResource(R.drawable.favfull);
        if (flag[3])
            fy.setBackgroundResource(R.drawable.favfull);
        if (flag[4])
            fz.setBackgroundResource(R.drawable.favfull);






        ImageView im = findViewById(R.id.ban);


        fv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (flag[0] == false)
                    fv.setBackgroundResource(R.drawable.favfull);
                else
                    fv.setBackgroundResource(R.drawable.favborder);
                flag[0] = !flag[0];
                store(e,flag[0],"v",i.getIntExtra("cat",1));
                Log.d("v",Boolean.toString(flag[0]));
            }
        });


        fw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (flag[1] == false)
                    fw.setBackgroundResource(R.drawable.favfull);
                else
                    fw.setBackgroundResource(R.drawable.favborder);
                flag[1] = !flag[1];
                store(e,flag[1],"w",i.getIntExtra("cat",1));
            }
        });



        fx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (flag[2] == false)
                    fx.setBackgroundResource(R.drawable.favfull);
                else
                    fx.setBackgroundResource(R.drawable.favborder);
                flag[2] = !flag[2];
                store(e,flag[2],"x",i.getIntExtra("cat",1));
            }
        });

        fy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (flag[3] == false)
                    fy.setBackgroundResource(R.drawable.favfull);
                else
                    fy.setBackgroundResource(R.drawable.favborder);
                flag[3] = !flag[3];
                store(e,flag[3],"y",i.getIntExtra("cat",1));
            }
        });



        fz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (flag[4] == false)
                    fz.setBackgroundResource(R.drawable.favfull);
                else
                    fz.setBackgroundResource(R.drawable.favborder);
                flag[4] = !flag[4];
                store(e,flag[4],"z",i.getIntExtra("cat",1));
            }
        });



        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent n = new Intent(getApplicationContext(), details.class);
                int temp = 0;
                switch (i.getIntExtra("cat", 1)) {

                    case 1:
                        n.putExtra("evename", 1 + temp);
                        break;
                    case 2:
                        n.putExtra("evename", 6 + temp);
                        break;
                    case 3:
                        n.putExtra("evename", 11 + temp);
                        break;
                    case 4:
                        n.putExtra("evename", 16 + temp);
                        break;
                    case 5:
                        n.putExtra("evename", 21 + temp);
                        break;
                    case 6:
                        n.putExtra("evename", 26 + temp);
                        break;
                    case 7:
                        n.putExtra("evename", 31 + temp);
                        break;
                    default:
                        n.putExtra("evename", 100);
                        break;
                }
                if(i.getIntExtra("cat",1)!=8)
                startActivity(n);
            }
        });


        w.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent n = new Intent(getApplicationContext(), details.class);
                int temp = 1;
                switch (i.getIntExtra("cat", 1)) {

                    case 1:
                        n.putExtra("evename", 1 + temp);
                        break;
                    case 2:
                        n.putExtra("evename", 6 + temp);
                        break;
                    case 3:
                        n.putExtra("evename", 11 + temp);
                        break;
                    case 4:
                        n.putExtra("evename", 16 + temp);
                        break;
                    case 5:
                        n.putExtra("evename", 21 + temp);
                        break;
                    case 6:
                        n.putExtra("evename", 26 + temp);
                        break;
                    case 7:
                        n.putExtra("evename", 31 + temp);
                        break;
                    default:
                        n.putExtra("evename", 100);
                        break;
                }
                startActivity(n);
            }
        });


        x.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent n = new Intent(getApplicationContext(), details.class);
                int temp = 2;
                switch (i.getIntExtra("cat", 1)) {
                    case 1:
                        n.putExtra("evename", 1 + temp);
                        break;
                    case 2:
                        n.putExtra("evename", 6 + temp);
                        break;
                    case 3:
                        n.putExtra("evename", 11 + temp);
                        break;
                    case 4:
                        n.putExtra("evename", 16 + temp);
                        break;
                    case 5:
                        n.putExtra("evename", 21 + temp);
                        break;
                    case 6:
                        n.putExtra("evename", 26 + temp);
                        break;
                    case 7:
                        n.putExtra("evename", 31 + temp);
                        break;
                    default:
                        n.putExtra("evename", 100);
                        break;
                }
                startActivity(n);
            }
        });


        y.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent n = new Intent(getApplicationContext(), details.class);
                int temp = 3;
                switch (i.getIntExtra("cat", 1)) {
                    case 1:
                        n.putExtra("evename", 1 + temp);
                        break;
                    case 2:
                        n.putExtra("evename", 6 + temp);
                        break;
                    case 3:
                        n.putExtra("evename", 11 + temp);
                        break;
                    case 4:
                        n.putExtra("evename", 16 + temp);
                        break;
                    case 5:
                        n.putExtra("evename", 21 + temp);
                        break;
                    case 6:
                        n.putExtra("evename", 26 + temp);
                        break;
                    case 7:
                        n.putExtra("evename", 31 + temp);
                        break;
                    default:
                        n.putExtra("evename", 100);
                        break;
                }
                startActivity(n);
            }
        });


        z.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent n = new Intent(getApplicationContext(), details.class);
                int temp = 4;
                switch (i.getIntExtra("cat", 1)) {
                    case 1:
                        n.putExtra("evename", 1 + temp);
                        break;
                    case 2:
                        n.putExtra("evename", 6 + temp);
                        break;
                    case 3:
                        n.putExtra("evename", 11 + temp);
                        break;
                    case 4:
                        n.putExtra("evename", 16 + temp);
                        break;
                    case 5:
                        n.putExtra("evename", 21 + temp);
                        break;
                    case 6:
                        n.putExtra("evename", 26 + temp);
                        break;
                    case 7:
                        n.putExtra("evename", 31 + temp);
                        break;
                    default:
                        n.putExtra("evename", 100);
                        break;
                }
                startActivity(n);
            }
        });








        switch (i.getIntExtra("cat", 1)) {
            case 1:
                im.setBackgroundResource(R.drawable.dance);
                TextView v1 = (TextView)v.findViewById(R.id.evename);
                v1.setText("Une Pirouette");
                v1.setTextColor(Color.parseColor("#56d787"));
                TextView w1 = (TextView)w.findViewById(R.id.evename);
                w1.setText("Rabble");
                w1.setTextColor(Color.parseColor("#56d787"));
                TextView x1 = (TextView)x.findViewById(R.id.evename);
                x1.setText("Twinning Moves");
                x1.setTextColor(Color.parseColor("#56d787"));
                y.setVisibility(View.INVISIBLE);
                z.setVisibility(View.INVISIBLE);
                break;
            case 2:
                im.setBackgroundResource(R.drawable.music);
                TextView v2 = (TextView)v.findViewById(R.id.evename);
                v2.setText("Melody Magic");
                v2.setTextColor(Color.parseColor("#991a85"));
                TextView w2 = (TextView)w.findViewById(R.id.evename);
                w2.setText("Melopacte");
                w2.setTextColor(Color.parseColor("#991a85"));
                TextView x2 = (TextView)x.findViewById(R.id.evename);
                x2.setText("Rhythm Gods");
                x2.setTextColor(Color.parseColor("#991a85"));
                y.setVisibility(View.INVISIBLE);
                z.setVisibility(View.INVISIBLE);
                break;
            case 3:
                im.setBackgroundResource(R.drawable.thearterical);
                TextView v3 = (TextView)v.findViewById(R.id.evename);
                v3.setText("Impersonate");
                v3.setTextColor(Color.parseColor("#9395bd"));
                TextView w3 = (TextView)w.findViewById(R.id.evename);
                w3.setText("What the Flix ?");
                w3.setTextColor(Color.parseColor("#9395bd"));
                x.setVisibility(View.INVISIBLE);
                y.setVisibility(View.INVISIBLE);
                z.setVisibility(View.INVISIBLE);
                break;
            case 4:
                im.setBackgroundResource(R.drawable.art);
                TextView v4 = (TextView)v.findViewById(R.id.evename);
                v4.setText("Art-Expo");
                v4.setTextColor(Color.parseColor("#512f96"));
                TextView w4 = (TextView)w.findViewById(R.id.evename);
                w4.setText("Strokes");

                w4.setTextColor(Color.parseColor("#512f96"));
                x.setVisibility(View.INVISIBLE);
                y.setVisibility(View.INVISIBLE);
                z.setVisibility(View.INVISIBLE);
                break;
            case 5:
                im.setBackgroundResource(R.drawable.literature);
                TextView v5 = (TextView)v.findViewById(R.id.evename);
                v5.setText("Flip Lip");
                v5.setTextColor(Color.parseColor("#5d900a"));
                TextView w5 = (TextView)w.findViewById(R.id.evename);
                w5.setText("Tick Talk");
                w5.setTextColor(Color.parseColor("#5d900a"));
                TextView x5 = (TextView)x.findViewById(R.id.evename);
                x5.setText("Shakespearean Diaries");
                x5.setTextColor(Color.parseColor("#5d900a"));
                TextView y5 = (TextView)y.findViewById(R.id.evename);
                y5.setText("AV Quiz");
                y5.setTextColor(Color.parseColor("#5d900a"));
                TextView z5 = (TextView)z.findViewById(R.id.evename);
                z5.setText("Noted Talks");
                z5.setTextColor(Color.parseColor("#5d900a"));
                break;
            case 6:
                im.setBackgroundResource(R.drawable.fun);
                TextView v6 = (TextView)v.findViewById(R.id.evename);
                v6.setText("Dumb,Dumber & Dumbest");
                v6.setTextSize(18f);
                v6.setTextColor(Color.parseColor("#17aeb2"));
                TextView w6 = (TextView)w.findViewById(R.id.evename);
                w6.setText("Boombox");
                w6.setTextColor(Color.parseColor("#17aeb2"));
                TextView x6 = (TextView)x.findViewById(R.id.evename);
                x6.setText("Da Vinci grid");
                x6.setTextColor(Color.parseColor("#17aeb2"));
                TextView y6 = (TextView)y.findViewById(R.id.evename);
                y6.setText("Dance off");
                y6.setTextColor(Color.parseColor("#17aeb2"));
                z.setVisibility(View.INVISIBLE);
                break;
            case 7:
                im.setBackgroundResource(R.drawable.online);
                TextView v7 = (TextView)v.findViewById(R.id.evename);
                v7.setText("Picturesque");
                v7.setTextColor(Color.parseColor("#c43d61"));
                TextView w7 = (TextView)w.findViewById(R.id.evename);
                w7.setText("Lip Synchro");
                w7.setTextColor(Color.parseColor("#c43d61"));
                TextView x7 = (TextView)x.findViewById(R.id.evename);
                x7.setText("Rubric Illustration");
                x7.setTextColor(Color.parseColor("#c43d61"));
                y.setVisibility(View.INVISIBLE);
                z.setVisibility(View.INVISIBLE);
                break;
            case 8:
                im.setBackgroundResource(R.drawable.ms);
                ((TextView) v.findViewById(R.id.evename)).setText("Masala coffee- the music band debuted in 2014 on a music show on Kappa TV is a band that performs basically in generes of folk, blues, pop and rock is here to blast the stage on 29th september. Don't miss it !\n\nTeam\nSooraj santhosh-lead vocal\nKeyneth Gerald-keyboard\nPaul Joseph-bass guitar\nPreeth Ps-lead guitar\nKrishna Raj-violin\nVarun sunil-percussion\nDaya sankar-drums\nDavid Crimson-guitar");
                ((TextView) v.findViewById(R.id.evename)).setTextSize(16);
                fv.setVisibility(View.GONE);
                x.setVisibility(View.INVISIBLE);
                y.setVisibility(View.INVISIBLE);
                z.setVisibility(View.INVISIBLE);
                w.setVisibility(View.INVISIBLE);


        }

    }



}
