package com.devlab.nitpy.leciel18;


public class eventdata {
    String title="Symphony";
    String desc="An Event";
    long time=0;
    int icon= R.drawable.ic_menu_send;
    boolean fav=false;

    public void setTitle(String t){
        this.title=t;

    }
    public void setDesc(String t){
        this.desc=t;

    }
    public void setTime(long t){
        this.time=t;

    }
    public void setIcon(int t){
        this.icon=t;

    }
    public void setFav(boolean t){
        this.fav=t;

    }



     public String getTitle(){
        return this.title;

     }
    public String getDesc(){
        return this.desc;

    }
    public long getTime(){
        return this.time;

    }
    public int getIcon(){
        return this.icon;

    }
    public boolean checkfav(){
        return this.fav;

    }



}
