package com.devlab.nitpy.leciel18;

import android.app.DownloadManager;
import android.content.ClipData;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.text.Layout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;


public class sch extends Fragment {

    final String[] t={"a","b","c"};
    final String[] d={"1","2","3"};
    static boolean flag=false;
    JSONObject jsonObject,rb;
    JSONArray ja;
    Resources r ;
    String p;
    SharedPreferences s;
    SharedPreferences.Editor e;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        final View v = inflater.inflate(R.layout.fragment_sch, container, false);

        s = PreferenceManager.getDefaultSharedPreferences(getContext());
        e = s.edit();
        r =getResources();
        p = getContext().getPackageName();



        try {
            jsonObject = new JSONObject(s.getString("sch",""));
        } catch (JSONException e1) {
            e1.printStackTrace();
        }


        if(jsonObject!=null) {
            int i = 0;
            for (char a = 'a'; a < 's'; i++) {


                try {
                    if (jsonObject.getJSONArray("schedule").getJSONObject(i).getString("day").equals("1")) {


                        ((TextView) v.findViewById(r.getIdentifier(a + "", "id", p)).findViewById(R.id.tit)).setText(jsonObject.getJSONArray("schedule").getJSONObject(i).getString("name"));
                        ((TextView) v.findViewById(r.getIdentifier(a + "", "id", p)).findViewById(R.id.tim)).setText(jsonObject.getJSONArray("schedule").getJSONObject(i).getString("time"));
                        ((TextView) v.findViewById(r.getIdentifier(a + "", "id", p)).findViewById(R.id.desc)).setText(jsonObject.getJSONArray("schedule").getJSONObject(i).getString("venue"));
                        a++;
                    }
                } catch (JSONException e1) {
                    e1.printStackTrace();
                }

            }

            v.findViewById(R.id.err).setVisibility(View.GONE);
        }
        else
        {
            v.findViewById(R.id.ll).setVisibility(View.GONE);
            v.findViewById(R.id.daysw).setVisibility(View.GONE);
            v.findViewById(R.id.err).setVisibility(View.VISIBLE);
        }




            RequestQueue q = Volley.newRequestQueue(getContext());
        JsonObjectRequest j=new JsonObjectRequest(Request.Method.GET, "https://api.jsonbin.io/b/5ba4b2570fbf2833e2299331/latest", null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject jsonObject) {
                e.putString("sch",jsonObject.toString()).commit();
                int i=0;
                try{


                for(char a='a';a<'s';i++) {


                        if (jsonObject.getJSONArray("schedule").getJSONObject(i).getString("day").equals("1")) {


                            ((TextView) v.findViewById(r.getIdentifier(a + "", "id", p)).findViewById(R.id.tit)).setText(jsonObject.getJSONArray("schedule").getJSONObject(i).getString("name"));
                            ((TextView) v.findViewById(r.getIdentifier(a + "", "id", p)).findViewById(R.id.tim)).setText(jsonObject.getJSONArray("schedule").getJSONObject(i).getString("time"));
                            ((TextView) v.findViewById(r.getIdentifier(a + "", "id", p)).findViewById(R.id.desc)).setText(jsonObject.getJSONArray("schedule").getJSONObject(i).getString("venue"));
                            a++;
                        }

                }



                    v.findViewById(R.id.ll).setVisibility(View.VISIBLE);
                    v.findViewById(R.id.daysw).setVisibility(View.VISIBLE);
                    v.findViewById(R.id.err).setVisibility(View.GONE);


                }catch (Exception e){
                        e.printStackTrace();
                    }
                }



        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {

            }
        });

        q.add(j);


        v.findViewById(R.id.daysw).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View vi) {


                try {
                    jsonObject = new JSONObject(s.getString("sch",""));
                } catch (JSONException e1) {
                    e1.printStackTrace();
                }


                int i=0;

                try {
                    if (flag) {
                        flag=!flag;
                        v.findViewById(R.id.daysw).setBackgroundResource(R.drawable.da2);
                        char a = 'a';
                        for (; i < jsonObject.getJSONArray("schedule").length(); i++) {


                            if (jsonObject.getJSONArray("schedule").getJSONObject(i).getString("day").equals("2")) {


                                ((TextView) v.findViewById(r.getIdentifier(a + "", "id", p)).findViewById(R.id.tit)).setText(jsonObject.getJSONArray("schedule").getJSONObject(i).getString("name"));
                                ((TextView) v.findViewById(r.getIdentifier(a + "", "id", p)).findViewById(R.id.tim)).setText(jsonObject.getJSONArray("schedule").getJSONObject(i).getString("time"));
                                ((TextView) v.findViewById(r.getIdentifier(a + "", "id", p)).findViewById(R.id.desc)).setText(jsonObject.getJSONArray("schedule").getJSONObject(i).getString("venue"));
                                v.findViewById(r.getIdentifier(a + "", "id", p)).setVisibility(View.VISIBLE);

                                a++;
                            }

                        }
                        v.findViewById(R.id.err).setVisibility(View.GONE);
                        for(;a<'s';a++){
                             v.findViewById(r.getIdentifier(a + "", "id", p)).setVisibility(View.GONE);
                        }



                    } else {

                        flag=!flag;
                        v.findViewById(R.id.daysw).setBackgroundResource(R.drawable.da1);
                        i = 0;
                        char a = 'a';
                        for (; i < jsonObject.getJSONArray("schedule").length(); i++) {


                            if (jsonObject.getJSONArray("schedule").getJSONObject(i).getString("day").equals("1")) {


                                ((TextView) v.findViewById(r.getIdentifier(a + "", "id", p)).findViewById(R.id.tit)).setText(jsonObject.getJSONArray("schedule").getJSONObject(i).getString("name"));
                                ((TextView) v.findViewById(r.getIdentifier(a + "", "id", p)).findViewById(R.id.tim)).setText(jsonObject.getJSONArray("schedule").getJSONObject(i).getString("time"));
                                ((TextView) v.findViewById(r.getIdentifier(a + "", "id", p)).findViewById(R.id.desc)).setText(jsonObject.getJSONArray("schedule").getJSONObject(i).getString("venue"));
                                v.findViewById(r.getIdentifier(a + "", "id", p)).setVisibility(View.VISIBLE);
                                a++;
                            }

                        }
                        v.findViewById(R.id.err).setVisibility(View.GONE);
                        for(;a<'s';a++){
                            v.findViewById(r.getIdentifier(a + "", "id", p)).setVisibility(View.GONE);
                        }



                    }


                }
                catch (JSONException jex){
                    jex.printStackTrace();
                }



            }
        });







       /* for(char i ='a'; i<'s';i++,j++) {
            try {
                jo = ja.getJSONObject(0);
            } catch (JSONException e) {
                ((View) v.findViewById(r.getIdentifier(Character.toString(i), "id", p))).setVisibility(View.GONE);
            }

            try {
                if (jo.getString("day") == "1") {
                    ((TextView) (v.findViewById(r.getIdentifier(Character.toString(i), "id", p))).findViewById(R.id.tit)).setText(jo.getString("name"));
                    ((TextView) (v.findViewById(r.getIdentifier(Character.toString(i), "id", p))).findViewById(R.id.desc)).setText(jo.getString("venue"));
                    ((TextView) (v.findViewById(r.getIdentifier(Character.toString(i), "id", p))).findViewById(R.id.tim)).setText(jo.getString("time"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        Button day=(Button) v.findViewById(R.id.daysw);
        day.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int j=0;
                try {
                    ja=new JSONArray(s.getString("sch",""));
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                for(char i ='a'; i<'s';i++,j++)
                {
                    try {
                        jo=ja.getJSONObject(j);
                    } catch (JSONException e) {
                        ((View) v.findViewById(r.getIdentifier(Character.toString(i),"id",p))).setVisibility(View.GONE);
                    }

                    try {
                        if (jo.getString("day")=="1"&&flag==true) {
                            ((TextView) (v.findViewById(r.getIdentifier(Character.toString(i), "id", p))).findViewById(R.id.tit)).setText(jo.getString("name"));
                            ((TextView) (v.findViewById(r.getIdentifier(Character.toString(i), "id", p))).findViewById(R.id.desc)).setText(jo.getString("venue"));
                            ((TextView) (v.findViewById(r.getIdentifier(Character.toString(i), "id", p))).findViewById(R.id.tim)).setText(jo.getString("time"));
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    try {
                        if (jo.getString("day").equals("2")&&flag==false) {
                            ((TextView) (v.findViewById(r.getIdentifier(Character.toString(i), "id", p))).findViewById(R.id.tit)).setText(jo.getString("name"));
                            ((TextView) (v.findViewById(r.getIdentifier(Character.toString(i), "id", p))).findViewById(R.id.desc)).setText(jo.getString("venue"));
                            ((TextView) (v.findViewById(r.getIdentifier(Character.toString(i), "id", p))).findViewById(R.id.tim)).setText(jo.getString("time"));
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }

            }
        });

*/
        /*final View a=v.findViewById(R.id.a);
        final View b=v.findViewById(R.id.b);
        final View c=v.findViewById(R.id.c);
        final View d=v.findViewById(R.id.d);
        final View e=v.findViewById(R.id.e);
        final View f=v.findViewById(R.id.f);
        final View g=v.findViewById(R.id.g);
        final View h=v.findViewById(R.id.h);
        final View i=v.findViewById(R.id.i);
        final View j=v.findViewById(R.id.j);
        final View k=v.findViewById(R.id.k);
        final View l=v.findViewById(R.id.l);
        final View m=v.findViewById(R.id.m);
        final View n=v.findViewById(R.id.n);
        final View o=v.findViewById(R.id.o);
        final View p=v.findViewById(R.id.p);
        final View q=v.findViewById(R.id.q);
        final View r=v.findViewById(R.id.r);



        Button day= (Button)v.findViewById(R.id.daysw);
        ((TextView) a.findViewById(R.id.tit)).setText("Inauguration");
        ((TextView) a.findViewById(R.id.desc)).setText("On Stage");
        ((TextView) a.findViewById(R.id.tim)).setText("09:00");

        ((TextView) b.findViewById(R.id.tit)).setText("Solo Dance - Prelims");
        ((TextView) b.findViewById(R.id.desc)).setText("On Stage");
        ((TextView) b.findViewById(R.id.tim)).setText("10:00");

        ((TextView) c.findViewById(R.id.tit)).setText("Solo Songs - Prelims");
        ((TextView) c.findViewById(R.id.desc)).setText("First Year Classroom");
        ((TextView) c.findViewById(R.id.tim)).setText("10:00");

        ((TextView) d.findViewById(R.id.tit)).setText("Debate");
        ((TextView) d.findViewById(R.id.desc)).setText("SF-1");
        ((TextView) d.findViewById(R.id.tim)).setText("10:00");

        ((TextView) e.findViewById(R.id.tit)).setText("Art");
        ((TextView) e.findViewById(R.id.desc)).setText("FF-5 & FF-6");
        ((TextView) e.findViewById(R.id.tim)).setText("10:00");

        ((TextView) f.findViewById(R.id.tit)).setText("Craft");
        ((TextView) f.findViewById(R.id.desc)).setText("FF-1 & FF-2");
        ((TextView) f.findViewById(R.id.tim)).setText("10:00");

        ((TextView) g.findViewById(R.id.tit)).setText("Dumb charades");
        ((TextView) g.findViewById(R.id.desc)).setText("SF-4");
        ((TextView) g.findViewById(R.id.tim)).setText("12:30");

        ((TextView) h.findViewById(R.id.tit)).setText("MIME");
        ((TextView) h.findViewById(R.id.desc)).setText("First Year Classroom");
        ((TextView) h.findViewById(R.id.tim)).setText("13:30");

        ((TextView) i.findViewById(R.id.tit)).setText("Short Film");
        ((TextView) i.findViewById(R.id.desc)).setText("SF-3");
        ((TextView) i.findViewById(R.id.tim)).setText("13:30");

        ((TextView) j.findViewById(R.id.tit)).setText("Dance Off");
        ((TextView) j.findViewById(R.id.desc)).setText("On Stage");
        ((TextView) j.findViewById(R.id.tim)).setText("14:00");

        ((TextView) k.findViewById(R.id.tit)).setText("Duet/Group Song");
        ((TextView) k.findViewById(R.id.desc)).setText("First Year Classroom");
        ((TextView) k.findViewById(R.id.tim)).setText("15:00");

        ((TextView) l.findViewById(R.id.tit)).setText("Duet Dance");
        ((TextView) l.findViewById(R.id.desc)).setText("On Stage");
        ((TextView) l.findViewById(R.id.tim)).setText("15:00");

        ((TextView) m.findViewById(R.id.tit)).setText("Shakespere Diaries");
        ((TextView) m.findViewById(R.id.desc)).setText("First Year Classroom");
        ((TextView) m.findViewById(R.id.tim)).setText("18:00");

        ((TextView) n.findViewById(R.id.tit)).setText("Special Performance");
        ((TextView) n.findViewById(R.id.desc)).setText("On Stage");
        ((TextView) n.findViewById(R.id.tim)).setText("18:00");

        ((TextView) o.findViewById(R.id.tit)).setText("Band");
        ((TextView) o.findViewById(R.id.desc)).setText("On Stage");
        ((TextView) o.findViewById(R.id.tim)).setText("18:30");

        ((TextView) p.findViewById(R.id.tit)).setText("Stand up comedy");
        ((TextView) p.findViewById(R.id.desc)).setText("On Stage");
        ((TextView) p.findViewById(R.id.tim)).setText("19:00");

        ((TextView) q.findViewById(R.id.tit)).setText("Solo Song - Finals");
        ((TextView) q.findViewById(R.id.desc)).setText("On Stage");
        ((TextView) q.findViewById(R.id.tim)).setText("20:00");

        ((TextView) r.findViewById(R.id.tit)).setText("Fashion Show");
        ((TextView) r.findViewById(R.id.desc)).setText("On Stage");
        ((TextView) r.findViewById(R.id.tim)).setText("21:00");

        day.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(flag==false){
                    view.setBackgroundResource(R.drawable.da1);

                    n.setVisibility(View.VISIBLE);
                    o.setVisibility(View.VISIBLE);
                    p.setVisibility(View.VISIBLE);
                    q.setVisibility(View.VISIBLE);
                    r.setVisibility(View.VISIBLE);

                    ((TextView) a.findViewById(R.id.tit)).setText("Inauguration");
                    ((TextView) a.findViewById(R.id.desc)).setText("On Stage");
                    ((TextView) a.findViewById(R.id.tim)).setText("09:00");

                    ((TextView) b.findViewById(R.id.tit)).setText("Solo Dance - Prelims");
                    ((TextView) b.findViewById(R.id.desc)).setText("On Stage");
                    ((TextView) b.findViewById(R.id.tim)).setText("10:00");

                    ((TextView) c.findViewById(R.id.tit)).setText("Solo Songs - Prelims");
                    ((TextView) c.findViewById(R.id.desc)).setText("First Year Classroom");
                    ((TextView) c.findViewById(R.id.tim)).setText("10:00");

                    ((TextView) d.findViewById(R.id.tit)).setText("Debate");
                    ((TextView) d.findViewById(R.id.desc)).setText("SF-1");
                    ((TextView) d.findViewById(R.id.tim)).setText("10:00");

                    ((TextView) e.findViewById(R.id.tit)).setText("Art");
                    ((TextView) e.findViewById(R.id.desc)).setText("FF-5 & FF-6");
                    ((TextView) e.findViewById(R.id.tim)).setText("10:00");

                    ((TextView) f.findViewById(R.id.tit)).setText("Craft");
                    ((TextView) f.findViewById(R.id.desc)).setText("FF-1 & FF-2");
                    ((TextView) f.findViewById(R.id.tim)).setText("10:00");

                    ((TextView) g.findViewById(R.id.tit)).setText("Dumb charades");
                    ((TextView) g.findViewById(R.id.desc)).setText("SF-4");
                    ((TextView) g.findViewById(R.id.tim)).setText("12:30");

                    ((TextView) h.findViewById(R.id.tit)).setText("MIME");
                    ((TextView) h.findViewById(R.id.desc)).setText("First Year Classroom");
                    ((TextView) h.findViewById(R.id.tim)).setText("13:30");

                    ((TextView) i.findViewById(R.id.tit)).setText("Short Film");
                    ((TextView) i.findViewById(R.id.desc)).setText("SF-3");
                    ((TextView) i.findViewById(R.id.tim)).setText("13:30");

                    ((TextView) j.findViewById(R.id.tit)).setText("Dance Off");
                    ((TextView) j.findViewById(R.id.desc)).setText("On Stage");
                    ((TextView) j.findViewById(R.id.tim)).setText("14:00");

                    ((TextView) k.findViewById(R.id.tit)).setText("Duet/Group Song");
                    ((TextView) k.findViewById(R.id.desc)).setText("First Year Classroom");
                    ((TextView) k.findViewById(R.id.tim)).setText("15:00");

                    ((TextView) l.findViewById(R.id.tit)).setText("Duet Dance");
                    ((TextView) l.findViewById(R.id.desc)).setText("On Stage");
                    ((TextView) l.findViewById(R.id.tim)).setText("15:00");

                    ((TextView) m.findViewById(R.id.tit)).setText("Shakespere Diaries");
                    ((TextView) m.findViewById(R.id.desc)).setText("First Year Classroom");
                    ((TextView) m.findViewById(R.id.tim)).setText("18:00");

                    ((TextView) n.findViewById(R.id.tit)).setText("Special Performance");
                    ((TextView) n.findViewById(R.id.desc)).setText("On Stage");
                    ((TextView) n.findViewById(R.id.tim)).setText("18:00");

                    ((TextView) o.findViewById(R.id.tit)).setText("Band");
                    ((TextView) o.findViewById(R.id.desc)).setText("On Stage");
                    ((TextView) o.findViewById(R.id.tim)).setText("18:30");

                    ((TextView) p.findViewById(R.id.tit)).setText("Stand up comedy");
                    ((TextView) p.findViewById(R.id.desc)).setText("On Stage");
                    ((TextView) p.findViewById(R.id.tim)).setText("19:00");

                    ((TextView) q.findViewById(R.id.tit)).setText("Solo Song - Finals");
                    ((TextView) q.findViewById(R.id.desc)).setText("On Stage");
                    ((TextView) q.findViewById(R.id.tim)).setText("20:00");

                    ((TextView) r.findViewById(R.id.tit)).setText("Fashion Show");
                    ((TextView) r.findViewById(R.id.desc)).setText("On Stage");
                    ((TextView) r.findViewById(R.id.tim)).setText("21:00");

                }
                else{
                    view.setBackgroundResource(R.drawable.da2);

                    ((TextView) a.findViewById(R.id.tit)).setText("Band");
                    ((TextView) a.findViewById(R.id.desc)).setText("Main Stage");
                    ((TextView) a.findViewById(R.id.tim)).setText("09:00");

                    ((TextView) b.findViewById(R.id.tit)).setText("JAM");
                    ((TextView) b.findViewById(R.id.desc)).setText("First Year Classroom");
                    ((TextView) b.findViewById(R.id.tim)).setText("10:00");

                    ((TextView) c.findViewById(R.id.tit)).setText("Dance - Group");
                    ((TextView) c.findViewById(R.id.desc)).setText("On Stage");
                    ((TextView) c.findViewById(R.id.tim)).setText("10:30");

                    ((TextView) d.findViewById(R.id.tit)).setText("Dance -Solo(Finals)");
                    ((TextView) d.findViewById(R.id.desc)).setText("On Stage");
                    ((TextView) d.findViewById(R.id.tim)).setText("13:00");

                    ((TextView) e.findViewById(R.id.tit)).setText("AV Quiz");
                    ((TextView) e.findViewById(R.id.desc)).setText("First Year Classroom");
                    ((TextView) e.findViewById(R.id.tim)).setText("14:00");

                    ((TextView) f.findViewById(R.id.tit)).setText("Beat Boxing");
                    ((TextView) f.findViewById(R.id.desc)).setText("On Stage");
                    ((TextView) f.findViewById(R.id.tim)).setText("14:30");

                    ((TextView) g.findViewById(R.id.tit)).setText("NO Ted Talks");
                    ((TextView) g.findViewById(R.id.desc)).setText("First Year Classroom");
                    ((TextView) g.findViewById(R.id.tim)).setText("15:00");

                    ((TextView) h.findViewById(R.id.tit)).setText("Da Vinci Grid");
                    ((TextView) h.findViewById(R.id.desc)).setText("SF1");
                    ((TextView) h.findViewById(R.id.tim)).setText("15:00");

                    ((TextView) i.findViewById(R.id.tit)).setText("College Band");
                    ((TextView) i.findViewById(R.id.desc)).setText("Main Stage");
                    ((TextView) i.findViewById(R.id.tim)).setText("16:00");

                    ((TextView) j.findViewById(R.id.tit)).setText("Validation");
                    ((TextView) j.findViewById(R.id.desc)).setText("On Stage");
                    ((TextView) j.findViewById(R.id.tim)).setText("17:00");

                    ((TextView) k.findViewById(R.id.tit)).setText("Masala Coffee");
                    ((TextView) k.findViewById(R.id.desc)).setText("Main Stage");
                    ((TextView) k.findViewById(R.id.tim)).setText("17:00");

                    ((TextView) l.findViewById(R.id.tit)).setText("Hip Hoppers");
                    ((TextView) l.findViewById(R.id.desc)).setText("Main Stage");
                    ((TextView) l.findViewById(R.id.tim)).setText("20:00");

                    ((TextView) m.findViewById(R.id.tit)).setText("DJ Night");
                    ((TextView) m.findViewById(R.id.desc)).setText("Main Stage");
                    ((TextView) m.findViewById(R.id.tim)).setText("21:00");


                    n.setVisibility(View.GONE);
                    o.setVisibility(View.GONE);
                    p.setVisibility(View.GONE);
                    q.setVisibility(View.GONE);
                    r.setVisibility(View.GONE);
                }
                flag=!flag;
            }
        });*/




        return v;
    }

}
