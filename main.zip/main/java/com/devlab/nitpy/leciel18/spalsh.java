package com.devlab.nitpy.leciel18;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.graphics.Typeface;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class spalsh extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_spalsh);



        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                Intent i= new Intent(getBaseContext(),MainActivity.class);
                startActivity(i);
                finish();

            }
        },2000);
        TextView i= (TextView) findViewById(R.id.lc);
        Typeface c_f=Typeface.createFromAsset(getAssets(),"fonts/Nature.ttf");
        i.setTypeface(c_f);
        i.setScaleX(0.8f);
        i.setScaleY(0.8f);
        i.setAlpha(0.0f);
        i.animate().alphaBy(1.0f).setDuration(1500).start();
        i.animate().scaleXBy(0.2f).setDuration(900).start();
        i.animate().scaleYBy(0.2f).setDuration(900).start();



    }
}
