package com.devlab.nitpy.leciel18;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.devlab.nitpy.leciel18.R;

import org.w3c.dom.Text;

public class ca extends ArrayAdapter {

    String[] tit;
    String[] des;
    Context c;

    public ca(@NonNull Context context, String[] t, String[] d) {
        super(context,0);
        c=context;
        tit=t;
        des=d;


    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        LayoutInflater l= LayoutInflater.from(c);
        View v=l.inflate(R.layout.item,null,true);
        TextView t= v.findViewById(R.id.tit);
        TextView d=v.findViewById(R.id.desc);
        t.setText(tit[position]);
        d.setText(des[position]);







        return v;

    }
}
