













package com.devlab.nitpy.leciel18;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.TabItem;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TableLayout;

import static android.support.design.widget.TabLayout.*;


public class Events extends Fragment {


    public void clickfn(View v) {
        Intent i = new Intent(getActivity(), details.class);
        i.putExtra("id", v.getId());
        startActivity(i);

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_events, container, false);
        TabLayout tl = (TabLayout) v.findViewById(R.id.tl);
        getFragmentManager().beginTransaction().replace(R.id.frame, new eve()).setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN).commit();
        TabLayout.Tab tb = tl.getTabAt(1);
        tb.select();

        tl.addOnTabSelectedListener(new OnTabSelectedListener() {
            @Override
            public void onTabSelected(Tab tab) {
                Fragment f = null;
                switch (tab.getPosition()) {
                    case 0:
                        f = new favor();
                        break;
                    case 1:
                        f = new eve();
                        break;
                    case 2:
                        f = new sch();

                }

                getFragmentManager().beginTransaction().replace(R.id.frame, f).setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN).commit();

            }

            @Override
            public void onTabUnselected(Tab tab) {

            }

            @Override
            public void onTabReselected(Tab tab) {

            }
        });
        return v;
    }
}





