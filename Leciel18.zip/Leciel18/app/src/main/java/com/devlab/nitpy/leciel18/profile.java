package com.devlab.nitpy.leciel18;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

public class profile extends Fragment {

            String text,em,pwd,tok,hash,ret;
            SharedPreferences sp;
            SharedPreferences.Editor ed;
            Button but;
            JSONObject j1,j2,jf;




    public String MD5(String md5) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            byte[] array = md.digest(md5.getBytes());
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < array.length; ++i) {
                sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).substring(1,3));
            }
            return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
        }
        return null;
    }


public void qrwrite(ImageView i,String text) {


    MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
    try {
        BitMatrix bitMatrix = multiFormatWriter.encode(text, BarcodeFormat.QR_CODE, 200, 200);
        BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
        Bitmap bitmap = barcodeEncoder.createBitmap(bitMatrix);
        i.setImageBitmap(bitmap);
    } catch (WriterException e) {
        e.printStackTrace();
    }
}
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        final View v = inflater.inflate(R.layout.fragment_profile, container, false);
        sp=PreferenceManager.getDefaultSharedPreferences(getContext());
        ed=sp.edit();


        CardView cardv=v.findViewById(R.id.cardv);
        LinearLayout ly=v.findViewById(R.id.fth);
        but=v.findViewById(R.id.signin);

        if(sp.getBoolean("login",false)){
            ly.setVisibility(View.GONE);
            cardv.setVisibility(View.VISIBLE);

            String qrs="https://lecielfest.com/lecmin/details.php?q="+sp.getString("lcid","LC0000");
            qrwrite(((ImageView)v.findViewById(R.id.qrc)),qrs);


            ((TextView)v.findViewById(R.id.name)).setText(sp.getString("name","admin"));
            ((TextView)v.findViewById(R.id.lcid)).setText(sp.getString("lcid","admin"));
            ((TextView)v.findViewById(R.id.college)).setText(sp.getString("college","admin"));
            ((TextView)v.findViewById(R.id.phone)).setText(sp.getString("phone","admin"));
        }


        but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View u) {
                em=((EditText)v.findViewById(R.id.email)).getText().toString();
                pwd=((EditText)v.findViewById(R.id.passtext)).getText().toString();
                hash=MD5(pwd);
                String url="https://lecielfest.com/mobileapi/login_mobile.php?email="+Uri.encode(em)+"&id="+hash;
                RequestQueue q=Volley.newRequestQueue(getContext());
                JsonObjectRequest j=new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject jsonObject) {
                        try {

                            String check=jsonObject.getString("login");
                            Log.i("ulti",check);
                            if(check.equals("1")){
                                String req="https://lecielfest.com/mobileapi/profile.php?q="+jsonObject.getString("token");



                                JsonObjectRequest fin=new JsonObjectRequest(Request.Method.GET, req, null, new Response.Listener<JSONObject>() {
                                    @Override
                                    public void onResponse(JSONObject jsonObject) {
                                        Log.i("final",jsonObject.toString());

                                        try {
                                            ed.putString("name", jsonObject.getString("FULL_NAME")).commit();
                                            ed.putString("lcid", jsonObject.getString("LC_ID")).commit();
                                            ed.putString("college", jsonObject.getString("COLLEGE")).commit();
                                            ed.putString("phone", jsonObject.getString("CONTACT")).commit();
                                            ed.putBoolean("login", true).commit();





                                            String qrs="https://lecielfest.com/lecmin/details.php?q="+sp.getString("lcid","LC0000");
                                            qrwrite(((ImageView)v.findViewById(R.id.qrc)),qrs);

                                            Log.i("fin",sp.getString("phone","admin"));


                                            ((TextView)v.findViewById(R.id.name)).setText(sp.getString("name","admin"));
                                            ((TextView)v.findViewById(R.id.lcid)).setText(sp.getString("lcid","admin"));
                                            ((TextView)v.findViewById(R.id.college)).setText(sp.getString("college","admin"));
                                            ((TextView)v.findViewById(R.id.phone)).setText(sp.getString("phone","admin"));


                                            v.findViewById(R.id.fth).setVisibility(View.GONE);
                                            v.findViewById(R.id.cardv).setVisibility(View.VISIBLE);






                                        }
                                        catch (Exception e){
                                            e.printStackTrace();
                                        }
                                    }
                                }, new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError volleyError) {

                                    }
                                });


                                Volley.newRequestQueue(getContext()).add(fin);















                            }
                            else v.findViewById(R.id.testd).setVisibility(View.VISIBLE);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }






                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {

                    }
                });
                q.add(j);














            }
        });

        return v;
    }



}
