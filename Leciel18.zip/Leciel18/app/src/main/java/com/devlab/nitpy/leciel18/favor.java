package com.devlab.nitpy.leciel18;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;



public class favor extends Fragment {

    View v2,v3;
    TextView t1,t2;
    String[] en={"Une Pirouette","Rabble","Twinning Moves","x","x","Melody Magic","Melopacte","Rhythm Gods","x","x","Impersonate","What the Flix?","x","x","x","Art-Expo","Strokes","x","x","x","Flip Lip", "Tick Talk", "Shakespearean diaries","AV Quiz","Noted Talks","Dumb,Dumber..est","Boombox","Da Vinci Grid","Dance off","x","Picturesque","Lip Sychro","Rubic Illustration","x","x","Masala Coffee"};

    String[] et={"Day 1 - 10:00, Inner Stage","Day 2 - 10:30, Inner Stage","Day 1 - 15:00, Inner Stage","x","x","Day 1 - 10:00, SF7","Day 1 - 18:30,Inner Stage","Day 1 - 15:00, SF7","x","x","Day 1 - 13:30, SF7","Day 1 - 13:30, SF3","x","x","x","Art-Expo 00:00","Strokes 00:00","x","x","x","Day 1 - 10:00, SF1", "Day 2 - 10:00, SF7", "Day 1 - 18:00, SF7","Day 2 - 14:00, SF7","Noted Talks00:00"," Dumb, Dumber, Dumbest00:00","Boombox00:00","Day 2 - 15:00, SF1","Day 1 - 14:00, Inner Stage","x","Online event","Online event","Online event"};
    int alpha=0,aio=0;





    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        SharedPreferences s= PreferenceManager.getDefaultSharedPreferences(getContext());

        View root =inflater.inflate(R.layout.fragment_favor, container, false);
        View v=root.findViewById(R.id.a);
        int fl=0;





       String[] sd={"v","w","x","y","z"};
       String[] pd={"1","2","3","4","5","6","7"};

        final Resources r=getResources();
        String n=getContext().getPackageName();
        Typeface cf=Typeface.createFromAsset(getContext().getAssets(),"fonts/Raleway.ttf");



        Log.d("gytu",en[24]);

        for (String c :pd){
            for (String d:sd){
                String cd=d+c;
                alpha+=1;
                if(s.getBoolean(cd,false)){
                    fl++;
                    String id="a"+Integer.toString(alpha);
                    v2=root.findViewById(r.getIdentifier(id,"id",n));
                    v2.setVisibility(View.VISIBLE);
                    t1=v2.findViewById(R.id.event_title);
                    t1.setText(en[alpha-1]);
                    t1.setTypeface(cf);
                    t2=v2.findViewById(R.id.event_time);
                    t2.setText(et[alpha-1]);
                    t2.setTypeface(cf);
                    v2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String id=r.getResourceName(v.getId());
                            String gen="com.devlab.nitpy.leciel18:id/a";
                            String s2=id.replaceAll(gen,"");
                            int ex=Integer.parseInt(s2);
                            Intent in=new Intent(getContext(),details.class);
                            in.putExtra("evename",ex);
                            startActivity(in);
                            Log.d("gert",s2);

                        }
                    });

                }

            }
        }

            if(fl==0){
            root.findViewById(R.id.nun).setVisibility(View.VISIBLE);
            }
            else
                root.findViewById(R.id.nun).setVisibility(View.GONE);

        return root;

        }




}
