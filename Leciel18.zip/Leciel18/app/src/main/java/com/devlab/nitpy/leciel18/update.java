package com.devlab.nitpy.leciel18;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class update extends Fragment {


    String c="",p1="",p2="",p3="",p4="";
    TextView giw;
    View vg;
    SharedPreferences sp;
    SharedPreferences.Editor e;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        sp= PreferenceManager.getDefaultSharedPreferences(getContext());
        e=sp.edit();


        final View root= inflater.inflate(R.layout.fragment_updates, container, false);

        final SimpleDateFormat df=new SimpleDateFormat("HH:mm");


        ((EditText)root.findViewById(R.id.com)).setText(sp.getString("commite","Hospitality"));


        final Resources r=getResources();
        final String n=getContext().getPackageName();
        giw=root.findViewById(R.id.p0);

        for(int j=4;j>=0;j--){

            Log.i("upd",sp.getString("u"+j,"ji"));
            ((TextView) root.findViewById(r.getIdentifier("p" + j, "id", n))).setText(sp.getString("u" + j, "Connect to internet for receiving latest updates"));

            if(!sp.getString("u"+j,"").equals("")) {

                root.findViewById(r.getIdentifier("pp" + j, "id", n)).setVisibility(View.VISIBLE);

            }
        }






        final DatabaseReference db= FirebaseDatabase.getInstance().getReference().child("updates");




        Query q=db.orderByKey().limitToLast(5);


        Button s=root.findViewById(R.id.send);
        s.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String up=df.format(new Date())+" | "+((EditText)root.findViewById(R.id.com)).getText().toString()+"\n\n\t"+((EditText)root.findViewById(R.id.up)).getText().toString();

                e.putString("commite",((EditText)root.findViewById(R.id.com)).getText().toString()).commit();
                db.push().setValue(up);
                Toast.makeText(getContext(),"Update posted",Toast.LENGTH_LONG).show();

            }
        });
























        return root;
    }


}
