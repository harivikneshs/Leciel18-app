package com.devlab.nitpy.leciel18;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class Fb extends Fragment {


    private DatabaseReference db= FirebaseDatabase.getInstance().getReference();
    private DatabaseReference user= FirebaseDatabase.getInstance().getReference();
    String f1,f2;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {




        final View v = inflater.inflate(R.layout.fragment_fb, container, false);

        final EditText ff=v.findViewById(R.id.fbFest);
        final EditText fa=v.findViewById(R.id.fbApp);

        final View a = v.findViewById(R.id.a);
        final View b = v.findViewById(R.id.b);
        final View c = v.findViewById(R.id.c);
        final View d = v.findViewById(R.id.d);
        final View e = v.findViewById(R.id.e);
        final View f = v.findViewById(R.id.f);

        Button s=v.findViewById(R.id.sub);
        s.setOnClickListener(new View.OnClickListener() {
                                 @Override
                                 public void onClick(View v) {

                                     user=db.child("Feedback").push();
                                     user.child("events").setValue(((RatingBar)a.findViewById(R.id.rating)).getRating());
                                     user.child("accomadation").setValue(((RatingBar)b.findViewById(R.id.rating)).getRating());
                                     user.child("food").setValue(((RatingBar)c.findViewById(R.id.rating)).getRating());
                                     user.child("transport").setValue(((RatingBar)d.findViewById(R.id.rating)).getRating());
                                     user.child("appui").setValue(((RatingBar)e.findViewById(R.id.rating)).getRating());
                                     user.child("appuse").setValue(((RatingBar)f.findViewById(R.id.rating)).getRating());


                                    f1=ff.getText().toString();
                                    f2=fa.getText().toString();

                                     user.child("fbfest").setValue(f1);
                                     user.child("fbapp").setValue(f2);



                                     Toast.makeText(getContext(),"Thanks for giving your feedback",Toast.LENGTH_LONG).show();



                                 }
                             });







        ((TextView) a.findViewById(R.id.ques)).setText("Events");
        ((TextView) b.findViewById(R.id.ques)).setText("Accommodation");
        ((TextView) c.findViewById(R.id.ques)).setText("Food");
        ((TextView) d.findViewById(R.id.ques)).setText("Transport");
        ((TextView) e.findViewById(R.id.ques)).setText("App Ui/Ux");
        ((TextView) f.findViewById(R.id.ques)).setText("App Usefulness");

        return v;
    }


}
