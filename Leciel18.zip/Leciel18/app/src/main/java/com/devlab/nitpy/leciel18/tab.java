package com.devlab.nitpy.leciel18;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.devlab.nitpy.leciel18.eve;
import com.devlab.nitpy.leciel18.favor;
import com.devlab.nitpy.leciel18.sch;

public class tab extends FragmentPagerAdapter {

    public tab(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int arg0) {
        switch (arg0) {
            case 0:
                return new favor();
            case 1:
                return new eve();
            case 2:
                return new sch();
            default:
                break;
        }
        return null;
    }

    @Override
    public int getCount() {
        return 3;
    }
}