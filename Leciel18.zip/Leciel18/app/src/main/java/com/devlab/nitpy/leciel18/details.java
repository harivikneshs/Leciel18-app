package com.devlab.nitpy.leciel18;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toolbar;

public class details extends AppCompatActivity {


        SharedPreferences sp;
        SharedPreferences.Editor ed;
        boolean bo; String s;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        Intent i=getIntent();
        Typeface c_f=Typeface.createFromAsset(getAssets(),"fonts/Raleway.ttf");
        TextView e=(TextView)findViewById(R.id.eventname);
        e.setTypeface(c_f);
        TextView t=(TextView)findViewById(R.id.descriunder);
        TextView r=(TextView)findViewById(R.id.rulesunder);
        ImageView im=(ImageView)findViewById(R.id.cover);




        sp= PreferenceManager.getDefaultSharedPreferences(this);
        ed=sp.edit();


        im.setScaleX(im.getScaleX()+1);
        im.setScaleY(im.getScaleY()+1);
        im.animate().scaleXBy(-1).setDuration(800).start();
        im.animate().scaleYBy(-1).setDuration(800).start();

        final Button fvb=findViewById(R.id.favbutton);

        int in=getIntent().getIntExtra("evename",1);
        int e1=in/5+1;
        int e2=in%5;
        s="";
        switch (e2){
            case 1:
                s="v"+e1;
                break;
            case 2:
                s="w"+e1;
                break;
            case 3:
                s="x"+e1;
                break;
            case 4:
                s="y"+e1;
                break;
            case 0:
                s="z"+(e1-5);
                break;

        }


        if(sp.getBoolean(s,false))
          fvb.setBackgroundResource(R.drawable.favfull);

        Log.d("gert",s);




       fvb.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               if(sp.getBoolean(s,false)) {


                   fvb.setBackgroundResource(R.drawable.favborder);
                   ed.putBoolean(s,false).commit();
               }
               else {
                   fvb.setBackgroundResource(R.drawable.favfull);
                   ed.putBoolean(s, true).commit();
               }

           }

       });


        switch (i.getIntExtra("evename",1)){

            case 1:
                e.setText("Une Pirouette");
                t.setText("Dance is an art of moving the body that draws a thin border for itself from walking, gymnastics and all other regular actions. Only a few can reflect those actions as a dance.\n" +
                        "Are you the one of those few? Come, join the Une Pirouette to give an eye feast for the audience and steal their hearts with your solo performance.");
                r.setText("1. Those participants who have register must report at the PR desk at reception ATLEAST TWO hours before the scheduled time of the event.\n" +
                        "2. Late registrations will be NOT be entertained.\n" +
                        "3. Participants must pick up slot at a time specified by the organizers to decide the order of appearance on stage. The first participant must be ready at least 30 MINUTES before the scheduled time of beginning of the event. Other Participants must be ready backstage when the preceding.\n" +
                        "4. Time of each performances is limited to 3-5 MINUTES.\n" +
                        "5. An official timekeeper will be present during the event. Timings are to be STRICTLY adhered. In case any Participant exceeds the time limit on stage, the music will be SWITCHED OFF after the designated time.\n" +
                        "6. Organizers are NOT responsible for the loss or damage of personal or confiscated property.\n" +
                        "7. Unruly behaviour can result in the DISQUALIFICATION.\n" +
                        "8. Vulgarity in any form is strictly prohibited and may warrant DISQUALIFICATION.\n" +
                        "9. Props are Allowed. Should bring of their own and must be SPECIFIED before the event.\n" +
                        "10. Use of fire, matches or any other inflammable substance is strictly prohibited.\n" +
                        "11. Organizers reserve the RIGHT to cancel any event or prize.\n" +
                        "12. All the participants are requested to bring their song on pendrive or any portable storage device and hand it over to Event Coordinator prior to performance.");
                im.setBackgroundResource(R.drawable.une);
                break;
            case 2:
                e.setText("Rabble");
                t.setText("Coming together is a beginning. Keeping together is a progress. Dancing together is the success.\n" +
                        "\n" +
                        "Group dances have always been a sight to see. Here many teams compete to step up and become the conquering cadre.");
                r.setText("1. Music must be pre-cut and prepared\n" +
                        "Please have a back-up of your music\n" +
                        "Please make sure the version is CLEAN/family friendly otherwise a penalty may be applied.\n" +
                        "2. No dangerous props to be used on stage, such as fire, swords, or knives.\n" +
                        "3. NO SCENERY ALLOWED.  Prop must be an integral part of the routine.  If you cannot hold it, stand on it, or hang from it, it is considered scenery and is not a prop.\n" +
                        "4. Participants agree that the time, manner, and method of judging the competition are final.  Judges break all ties.  No teacher, student, or parent will question a judge.\n" +
                        "5. Time limit 3 min strict\n" +
                        "If time limit exceeded then a penalty point will be imposed\n" +
                        "6. Its better to bring two pendrives\n" +

                        "7. May or may not be a couple, leave the choice to the participants\n" +
                        "8. Friends or coaches of the participants should not step on the stage before,during or after the act is performed\n" +
                        "9. No assessment of the dance will be done it they leave the dance in the middle\n" +
                        "10. Get your own props..that must me informed to the coordinators prior the competition");
                im.setBackgroundResource(R.drawable.rabble);
                break;
            case 3:
                e.setText("Twinning Moves");
                t.setText("Are the dance events just for solo and group? \n" +
                        "No, not at all. We also conduct a Duet competition.if  you and your dance partner are romantic dancers?. Twinning Moves welcomes you to join the stage and mesmerize the crowd with your Duet.  We are eager to see your pair on the stage.");
                r.setText("1. Maximum team strength allowed is 20 dancers + 3 helpers\n" +
                        "2. On stage maximum 10 members allowed at a time. Rest can rotate between rounds.\n" +
                        "3. In Case no. of participants are more, there will be a preliminary round.\n" +
                        "4. Time limit (excluding briefing time) – Max: 8 min. Min: 4 min.\n" +
                        "5. All forms of dance allowed. Fusion allowed.\n" +
                        "6. Weightage for costumes, music, choreography and coordination. Props can be used. \n" +
                        "7. Negative marking on exceeding time limit. \n" +
                        "8. Disqualification on exceeding the number of participants.\n" +
                        "9. Get your own CD/pen-drive with music for the dance. No audio cassettes will be\n" +
                        "allowed.\n" +
                        "10. Teams will be judged on the basis of their own prepared sequence.\n" +
                        "11. Teams need to show all the props which they might be using in their performance before the performance itself. \n" +
                        "12. Props using fire are strictly prohibited.\n" +
                        "13. Teams also need to show at least a single set of costumes they will be wearing for their performance.\n" +
                        "14. In case of any issue, final decision will be taken by the event coordinators.\n" +
                        "15. Performances with dangerous stunts will be at one's own risk.\n" +
                        "16. Provocative clothing and abusive song choices are not entertained.");
                im.setBackgroundResource(R.drawable.twinning);
                break;
            case 6:
                e.setText("Melody Magic");
                t.setText("“Where words fail, music speaks.”\n" +
                        " ― Hans Christian Andersen\n" +
                        "Are you the one who can prove this? Do you have a beautiful voice and passion for singing?\n" +
                        "Come, join us and grab the chance of mesmerizing the audiences and get a chance to become the champion of the champions in Melody Magic.");
                r.setText("1.Choice of song and language is open to the participants but the song should not have any offensive or disrespectful words or lines. The participant shall be stopped and disqualified immediately if the instructions are not followed.\n" +
                        "2. The time allotted to each participant is 3 – 4 minutes. If the participant exceeds the given time, he/she shall be disqualified without prior notice.\n" +
                        "3. Every participant must bring their college ID card with them, without which he/she will NOT be allowed to participate.\n" +
                        "4. Participant will NOT be allowed to refer to the lyrics while singing.\n" +
                        "5. The participants will be judged on the song selection, voice quality, clarity, rhythm and their appeal to the audience.\n" +
                        "6. If participants are singing along with a sound track, they should submit the sound track in a pen drive at least one and half hour prior to the start of the event.\n" +
                        "7. The participants should bring their own musical instrument if required in their performance.\n" +
                        "8. The decision of the judges will be final.\n");
                im.setBackgroundResource(R.drawable.solo);
                break;
            case 7:
                e.setText("Melopacte");
                t.setText("Are you a group of talented musicians? Come with your group and make the event unison to your band here on the Melopacte platform. Making the crowd sing to you is the best achievement of the band and here is a great chance in the name of Melopacte to become the best band at the event.");
                r.setText("1. Language – Any language of India (Hindi, English, Tamil etc.).\n" +
                        "2. Maximum 10 members can participate from a team.\n" +
                        "3. A Drum kit, keyboard , Acoustic guitar, Bass guitar and Electric guitar will be provided by the college.\n" +
                        "4. Participants can also bring their own instruments other than those which are mentioned above. \n" +
                        "5. At least once instrumentalist should be there. Performances without any instrument are not accepted.\n" +
                        "6. Time duration per team is maximum 15 minutes (excluding setting time).\n" +
                        "7. Any composition can be performed but original compositions will be preferred.\n" +
                        "8. Pre-recorded sounds and effects are not allowed.\n" +
                        "9. Obscenity in behaviour or lyrics will be strictly prohibited.\n" +
                        "10. In any case, Judges’ decision will be final and binding.");
                im.setBackgroundResource(R.drawable.melopacte);
                break;
            case 8:
                e.setText("Rhythm Gods");
                t.setText("The Gods have come singing songs of might and glory. The choice is up to you to challenge them and become Gods yourselves.\n" +
                        "\n" +
                        "Unity is Strength. It’s a group competition where you sing in symphony along with your team. Bring out the best in you by uniting your voices as one.");
                r.setText("1. A team of 6 participants and 3 accompanist only\n" +
                        "2. Minimum time is not less than 2 minutes and more than 5 minutes. Timings are to be strictly adhered\n" +
                        "3. Vulgarity or obscenity must be avoided in action, costume and gesture of the singing.\n" +
                        "4. Contestants are not permitted to leave the stage area during their performance\n" +
                        "5. Participants must report at the PR desk at reception AT LEAST TWO hour before the scheduled time of the event\n" +
                        "6. Late registration will not be entertained.");
                im.setBackgroundResource(R.drawable.rythm);
                break;
            case 11:
                e.setText("Impersonate");
                t.setText("Do you have a group that is expert in conveying the whole information without a single syllable coming out of your mouth? Join the Impersonate, enact a situation and make the audience laugh or cry at you acts, you succeed if you make them emotional to the topic you are spreading. ");
                r.setText("1. Every participant must bring their college id cards with them without which he / she will not be allowed to participate. (each respective member in the group).\n" +
                        "2. No act shall contain any offensive, obscene, disrespectful actions or gestures. The act will be stopped and immediately disqualified if instructions are not followed.\n" +
                        "3. Maximum of 10 members can form a group.\n" +
                        "4. Each group can perform only for 5 – 6 minutes. Negative marks will be awarded for exceeding the time limit.\n" +
                        "5. The act should not contain lip sync and dialogues.\n" +
                        "6. Only 5 – 6 Props can be used. Marks for props will be awarded.\n" +
                        "7. Music only without wordings is allowed.\n" +
                        "   Judgement will be based on the following criteria:\n" +
                        "    • Innovation\n" +
                        "    • Depiction of the situation\n" +
                        "    • Props\n" +
                        "    • Team Work\n" +
                        "    • Expressions\n" +
                        "    • Make up");
                im.setBackgroundResource(R.drawable.mime);
                break;
            case 12:
                e.setText("What the Flix?");
                t.setText("Are you a movie lover? Is a writer in you, waiting for a chance? Are you curious to see your face on the screen? Are you the one who admires to taste the 24 crafts of the film? Here is the best choice for you. What the flix? gives you an opportunity to showcase your creativity on the 24 crafts. Make a short film with the help of your team and get a chance of appreciation from all the eyes seeing it at the event. ");
                r.setText("1. No restriction on topic. However topics that are offensive to certain community, religion, gender, etc are strictly prohibited and will lead to direct disqualification.Nudity is not allowed.\n" +
                        "2. Maximum time limit : 15 min.\n" +
                        "3. The language prefered is English, however other languages are also allowed only if there is English subtitles.\n" +
                        "4. A brief discussion of topic chosen must be provided during the registration to lecielfest@gmail.com\n" +
                        "5. The script must be original. \n" +
                        "6. Forging of identity will disqualify the participants.\n" +
                        "7. Participants are not to question the marking done by the judges. \n" +
                        "8. Participants should posses their college id card while reporting for the event.\n" +
                        "9. Proof for registering for the event must be produced at the time of reporting\n" +
                        "10. No refund will be given.");
                im.setBackgroundResource(R.drawable.shortfilm);
                break;
            case 16:
                e.setText("Art Expo");
                t.setText("Imagine. Design. Invent. Time to showcase your mind for the entire world to see.\n" +
                        "\n" +
                        "Come and showcase your artistic creations along with many other talented artisans.");
                r.setText("To be revealed onspot...");
                im.setBackgroundResource(R.drawable.craftexpo);
                break;
            case 17:
                e.setText("Strokes");
                t.setText("A great painter is the one who makes the whole world to understand his views without the language barrier.\n" +
                        "The Strokes event is searching for the best artist in painting. The Picasso of the event is hiding somewhere. But we are sure he reads this.\n" +
                        "If you feel you are the Picasso of this event you are hearty welcome into the event and get a chance to win the title. ");
                r.setText("Time limit : 90 minutes\n" +
                        "\n" +
                        "    Drawing should be made on A3 sheet that will be provided by us.\n" +
                        "\n" +
                        "    Rest of the other kits for drawing like pencils,paints,colours etc should be brought.\n" +
                        "\n" +
                        "    Any kind of colours can be used by participants.");
                im.setBackgroundResource(R.drawable.strokes);
                break;
            case 21:
                e.setText("Flip Lip");
                t.setText("Life gives nothing in straight and we are seeking for the contestants who are really aware of the pros and cons of everything all the times. \n" +
                        "We confuse, twist, tense you by flipping your point of view for the same topic. \n" +
                        "Only that person who can flip the point of view instantaneously according to the instructions given will be the winner of the event.\n" +
                        "Are you ready? Come let's face the debate.");
                r.setText("To be revealed onspot ...");
                im.setBackgroundResource(R.drawable.fliplip);
                break;
            case 22:
                e.setText("Tick Talk");
                t.setText("One minute of life is not even a millionth of your lifetime. What can you do in that one minute? Are you taking one minute to just think about it?\n" +
                        "We came up with an event JAM, to make you win the applause of all the spectators.\n" +
                        "You’ve got a minute to win it. Bend your thoughts, play quick and effective and impress the jury to be the winner of the event.");
                r.setText("To be revealed onspot ...");
                im.setBackgroundResource(R.drawable.ticktalk);
                break;
            case 23:
                e.setText("Shakespearean Diaries");
                t.setText("Have you ever forgot the middle part of the answer and wrote a story to make it up the length of the actual answer?\n" +
                        "If you are an expert in it, well then there is an event which is designed for you. Build a story that links the starting and ending parts of the stories given by the jury and the best filler among the contestants will be the winner of the event.");
                r.setText("To be revealed onspot ...");
                im.setBackgroundResource(R.drawable.shakespeare);
                break;
            case 24:
                e.setText("AV Quiz");
                t.setText("Dig deep into your knowledge. Plunder your brain. Be pushed to the limits in the Battle of the Brains.\n" +
                        "\n" +
                        "Showcase your cerebral prowess in a set of challenging audio and visual questionnaires.");
                r.setText("To be revealed onspot ...");
                im.setBackgroundResource(R.drawable.av_quiz);
                break;
            case 25:
                e.setText("Noted Talks");
                t.setText("There is no life that starts their life from scratch. We only continue on the path that is laid by our previous generations. \n" +
                        "The Noted Talks presents the experienced predecessors to teach and inspire the youngsters showing the path they built and the pain they took to do it. ");
                r.setText("To be revealed onspot ...");
                im.setBackgroundResource(R.drawable.notedtalks);
                break;
            case 26:
                e.setText("Dumb,Dumber & Dumbest");
                t.setText("To be revealed onspot ...");
                r.setText("To be revealed onspot ...");
                im.setBackgroundResource(R.drawable.dumb);
                break;
            case 27:
                e.setText("Boombox");
                t.setText("To be revealed onspot ...");
                r.setText("To be revealed onspot ...");
                im.setBackgroundResource(R.drawable.boombox);
                break;
            case 28:
                e.setText("Da Vinci Grid");
                t.setText("To be revealed onspot ...");
                r.setText("To be revealed onspot ...");
                im.setBackgroundResource(R.drawable.davinci);
                break;
            case 29:
                e.setText("Dance Off");
                t.setText("To be revealed onspot ...");
                r.setText("To be revealed onspot ...");
                im.setBackgroundResource(R.drawable.dumb);
                break;
            case 31:
                e.setText("Picturesque");
                t.setText("“Photography is a way of feeling, of touching, of loving. What you have caught on film is captured forever… It remembers little things, long after you have forgotten everything.”\n" +
                        "\n" +
                        "— Aaron Siskind\n" +
                        "\n" +
                        "Not everyone one can present the true pleasure of nature on the paper. Are you the one in few? Then you have an opportunity to showcase your talent. Come, join us and get a chance to win the hearts of the spectators along with the prize.");
                r.setText("    • The picture should be the original work of the participant and not copied from any source.\n" +
                        "    • The picture should not be edited using any editorial tool. Cropping the picture is fine.\n" +
                        "    • Participants are required to e-mail the picture along with their Name, Facebook ID name, College ID and a suitable caption, to leciel.nitpy@gmail.com\n" +
                        "    • Caption won’t be having evaluated. \n" +
                        "    • The picture will be posted on our FB page. The picture won’t be posted if found vulgar or could potentially hurt the feelings of any community.\n" +
                        "    • Winner will be decided based on the reactions on the picture\n" +
                        "1 point for good reaction\n" +
                        "5 points for excellent reaction\n" +
                        "-1 point for bad reaction\n" +
                        "Rest all the reactions have 2 points \n" +
                        "    • Participants are not allowed to use any application to increase the number of likes.\n" +
                        "    • Participants are allowed to share the picture from our FB page.\n" +
                        "    • If the participant is found violating any rule, he/she will be disqualified immediately");
                im.setBackgroundResource(R.drawable.photo);
                break;
            case 32:
                e.setText("Lip Synchro");
                t.setText("Are you a movie lover? Have you ever wondered how your favorite actor/ actress does their lip sync to their actions? Do you want to experience the similar kind of feeling?\n" +
                        "If your answer is yes, congratulations you are on the right event. Join us and experience the beauty in it.\n" +
                        "Make your lips to sync along the actions and taste the flavor of joy you get through lip Synchro.\n" +
                        "We are ready to admire your talent. Are you ready to showcase yourself?");
                r.setText("1. The video should be made using Musical.ly/ Tik Tok application and should be original work of the participant.\n" +
                        "2. The video can be in any language.\n" +
                        "3. Musical.ly/ Tik Tok video should be e-mailed to leciel.nitpy@gmail.com along with the Name, Facebook ID name and College ID.\n" +
                        "4. The video should not be vulgar, should not contain swear word and should not hurt feelings of any community.\n" +
                        "5. The video will be posted on our FB page.\n" +
                        "6. Winner will be decided based on the reactions on the video\n" +
                        "    1 point for \n" +
                        "    5 points for \n" +
                        "    -1 point for  \n" +
                        "    Rest all the reactions have 2 points \n" +
                        "7. Participants are not allowed to use any application to increase the number of likes.\n" +
                        "8. Participants can share the video from our FB page.\n" +
                        "9. If the participant is found violating any rule, he/she will be disqualified immediately");
                im.setBackgroundResource(R.drawable.lipsync);
                break;
            case 33:
                e.setText("Rubric Illustration");
                t.setText("Have you ever felt proud of listening to “Wah Wah” from the audience? Are you that naughty guy who always caption everything?\n" +
                        "Yes? Well, Rubric Illustration provides you with a great platform to grasp millions of appreciations. Come, join you and kill the show with you soothing captions. We are waiting for you.");
                r.setText("1. Participant are supposed to caption the picture posted on our FB page.\n" +
                        "2. The caption should be e-mailed to leciel.nitpy@gmail.com along with Name, Facebook ID name and College ID.\n" +
                        "3. Caption should be related to the picture and should be in English\n" +
                        "4. The caption should not be more than 20 words. \n" +
                        "5. Caption will be posted on our FB page along with the picture.\n" +
                        "6. Winner will be decided based on the reactions on the caption.\n" +
                        "   1 point for \n" +
                        "   5 points for \n" +
                        "   -1 point for  \n" +
                        "   Rest all the reactions have 2 points \n" +
                        "7. Participants are not allowed to use any application to increase the number of likes.\n" +
                        "8. Participants can share the picture along with the caption from our FB page.\n" +
                        "9. If the participant is found violating any rule, he/she will be disqualified immediately");
                im.setBackgroundResource(R.drawable.caption);
                break;

        }

    }
}
